import { createContext, useContext, useEffect, useMemo, useReducer, useRef, useState } from "react";
import { reducer, initialState } from "./reducer";
import { fakeSave } from "./api";
import { useLocalStorage } from "./useLocalStorage";

const StoreContext = createContext(null);

export function StoreProvider({ children }) {
  const [saved, setSaved] = useLocalStorage("little-kanban-data", initialState);
  const [state, dispatch] = useReducer(reducer, saved);
  const [toast, setToast] = useState("");
  const id = useRef(Math.random().toString(36).slice(2));
  const syncing = useRef(false);
  const channel = useRef(null);

  useEffect(() => {
    const { past, future, ...data } = state;
    setSaved({ ...data, past: [], future: [] });
  }, [state, setSaved]);

  useEffect(() => {
    if (!("BroadcastChannel" in window)) return;
    channel.current = new BroadcastChannel("little-kanban-sync");
    channel.current.onmessage = (event) => {
      if (event.data.from !== id.current) {
        syncing.current = true;
        dispatch({ type: "SYNC", data: event.data.data });
        setTimeout(() => { syncing.current = false; }, 0);
      }
    };
    return () => channel.current?.close();
  }, []);

  useEffect(() => {
    if (syncing.current || !channel.current) return;
    const { past, future, ...data } = state;
    channel.current.postMessage({ from: id.current, data });
  }, [state]);

  function change(action) {
    const before = state;
    dispatch(action);
    fakeSave().catch((error) => {
      dispatch({ type: "RESTORE", state: before });
      setToast(error.message);
      setTimeout(() => setToast(""), 3500);
    });
  }

  const value = useMemo(() => ({ state, dispatch, change, toast }), [state, toast]);
  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  return useContext(StoreContext);
}
