import { fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";
import App from "./App";

vi.mock("./api", () => ({ fakeSave: () => Promise.resolve() }));

describe("действия на доске", () => {
  beforeEach(() => {
    localStorage.clear();
    window.history.replaceState(null, "", "/boards/demo");
  });

  it("создаёт карточку, перетаскивает её в другую колонку и отменяет перенос", async () => {
    const user = userEvent.setup();
    render(<App />);

    const addButtons = await screen.findAllByRole("button", { name: /добавить карточку/i });
    await user.click(addButtons[0]);
    await user.type(screen.getByLabelText("Название"), "Проверить сценарий");
    await user.click(screen.getByRole("button", { name: "Сохранить" }));

    const cardButton = await screen.findByRole("button", { name: "Изменить Проверить сценарий" });
    const card = cardButton.closest(".task-card");
    const columns = [...document.querySelectorAll(".column")];
    const targetColumn = columns.find((column) => within(column).queryByRole("heading", { name: /готово/i }));
    const transfer = { data: "", setData(_type, value) { this.data = value; }, getData() { return this.data; } };

    fireEvent.dragStart(card, { dataTransfer: transfer });
    fireEvent.drop(targetColumn, { dataTransfer: transfer });
    await waitFor(() => expect(within(targetColumn).getByText("Проверить сценарий")).toBeInTheDocument());

    fireEvent.keyDown(window, { key: "z", ctrlKey: true });
    await waitFor(() => expect(within(columns[0]).getByText("Проверить сценарий")).toBeInTheDocument());
  });
});
