export const startData = {
  boards: { demo: { id: "demo", title: "Моя первая доска" } },
  boardOrder: ["demo"],
  columns: {
    todo: { id: "todo", boardId: "demo", title: "Нужно сделать" },
    doing: { id: "doing", boardId: "demo", title: "В работе" },
    done: { id: "done", boardId: "demo", title: "Готово" },
  },
  columnOrder: { demo: ["todo", "doing", "done"] },
  cards: {
    c1: { id: "c1", columnId: "todo", title: "Продумать структуру проекта", description: "Определить основные страницы и компоненты.", tags: ["планирование"] },
    c2: { id: "c2", columnId: "todo", title: "Подготовить дизайн", description: "Выбрать цвета и оформление доски.", tags: ["дизайн"] },
    c3: { id: "c3", columnId: "doing", title: "Собрать первый экран", description: "Шапка и карточки задач.", tags: ["разработка"] },
  },
  cardOrder: { todo: ["c1", "c2"], doing: ["c3"], done: [] },
};

export function makeId() {
  return Math.random().toString(36).slice(2, 10);
}
