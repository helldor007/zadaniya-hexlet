import { Component, lazy, Suspense, useEffect, useState } from "react";
import { StoreProvider, useStore } from "./Store";
import "./styles.css";

const BoardsPage = lazy(() => import("./BoardsPage"));
const BoardPage = lazy(() => import("./BoardPage"));

function ErrorFallback({ retry }) {
  return <div className="not-found"><h2>Доска не загрузилась</h2><p>Попробуйте открыть её ещё раз.</p><button className="button primary" onClick={retry}>Попробовать снова</button></div>;
}

class BoardErrorBoundary extends Component {
  state = { error: false, attempt: 0 };
  static getDerivedStateFromError() { return { error: true }; }
  retry = () => this.setState((state) => ({ error: false, attempt: state.attempt + 1 }));
  render() {
    if (this.state.error) return <ErrorFallback retry={this.retry} />;
    return <BoardPage key={this.state.attempt} {...this.props} />;
  }
}

function usePath() {
  const [path, setPath] = useState(location.pathname + location.search);
  useEffect(() => {
    const update = () => setPath(location.pathname + location.search);
    window.addEventListener("popstate", update);
    return () => window.removeEventListener("popstate", update);
  }, []);

  function navigate(to) {
    history.pushState(null, "", to);
    setPath(location.pathname + location.search);
  }
  return [path, navigate];
}

function Toast() {
  const { toast } = useStore();
  return toast ? <div className="toast" role="alert">{toast}</div> : null;
}

function Routes() {
  const [path, navigate] = usePath();
  const pathname = path.split("?")[0];
  useEffect(() => {
    if (pathname === "/") navigate("/boards");
  }, [pathname]);

  useEffect(() => {
    const undo = () => window.dispatchEvent(new CustomEvent("app-undo"));
    const redo = () => window.dispatchEvent(new CustomEvent("app-redo"));
    window.addEventListener("kanban-undo", undo);
    window.addEventListener("kanban-redo", redo);
    return () => {
      window.removeEventListener("kanban-undo", undo);
      window.removeEventListener("kanban-redo", redo);
    };
  }, []);

  return <>
    <header className="topbar"><a href="/boards" className="logo" onClick={(event) => { event.preventDefault(); navigate("/boards"); }}><span className="logo-icon">◈</span> доски</a><span className="topbar-note">пространство для идей</span></header>
    <Suspense fallback={<div className="loading">Загружаем страницу…</div>}>
      {pathname === "/boards" ? <BoardsPage navigate={navigate} /> : pathname.startsWith("/boards/") && pathname.split("/").length === 3
        ? <BoardErrorBoundary key={pathname} boardId={decodeURIComponent(pathname.split("/")[2])} navigate={navigate} />
        : <main className="not-found"><span className="not-found-code">404</span><h1>Такой страницы нет</h1><button className="button primary" onClick={() => navigate("/boards")}>Вернуться к доскам</button></main>}
    </Suspense>
    <Toast />
  </>;
}

function HistoryKeys() {
  const { dispatch } = useStore();
  useEffect(() => {
    const undo = () => dispatch({ type: "UNDO" });
    const redo = () => dispatch({ type: "REDO" });
    window.addEventListener("app-undo", undo);
    window.addEventListener("app-redo", redo);
    return () => { window.removeEventListener("app-undo", undo); window.removeEventListener("app-redo", redo); };
  }, [dispatch]);
  return null;
}

export default function App() {
  return <StoreProvider><HistoryKeys /><Routes /></StoreProvider>;
}
