import { startData } from "./data";

export const initialState = { ...startData, past: [], future: [] };

function dataOnly(state) {
  const { past, future, ...data } = state;
  return data;
}

function saveStep(state, nextData) {
  return { ...nextData, past: [...state.past, dataOnly(state)].slice(-50), future: [] };
}

export function reducer(state, action) {
  if (action.type === "UNDO") {
    if (!state.past.length) return state;
    const previous = state.past[state.past.length - 1];
    return { ...previous, past: state.past.slice(0, -1), future: [dataOnly(state), ...state.future].slice(0, 50) };
  }
  if (action.type === "REDO") {
    if (!state.future.length) return state;
    return { ...state.future[0], past: [...state.past, dataOnly(state)].slice(-50), future: state.future.slice(1) };
  }
  if (action.type === "RESTORE") return action.state;
  if (action.type === "SYNC") return { ...action.data, past: state.past, future: state.future };

  const data = dataOnly(state);
  switch (action.type) {
    case "ADD_BOARD":
      return saveStep(state, { ...data, boards: { ...data.boards, [action.board.id]: action.board }, boardOrder: [...data.boardOrder, action.board.id], columnOrder: { ...data.columnOrder, [action.board.id]: [] } });
    case "RENAME_BOARD":
      return saveStep(state, { ...data, boards: { ...data.boards, [action.id]: { ...data.boards[action.id], title: action.title } } });
    case "DELETE_BOARD": {
      const boards = { ...data.boards };
      delete boards[action.id];
      const columns = { ...data.columns };
      const cards = { ...data.cards };
      const columnOrder = { ...data.columnOrder };
      const cardOrder = { ...data.cardOrder };
      (columnOrder[action.id] || []).forEach((colId) => {
        (cardOrder[colId] || []).forEach((cardId) => delete cards[cardId]);
        delete cardOrder[colId];
        delete columns[colId];
      });
      delete columnOrder[action.id];
      return saveStep(state, { ...data, boards, columns, cards, columnOrder, cardOrder, boardOrder: data.boardOrder.filter((id) => id !== action.id) });
    }
    case "ADD_COLUMN":
      return saveStep(state, { ...data, columns: { ...data.columns, [action.column.id]: action.column }, columnOrder: { ...data.columnOrder, [action.column.boardId]: [...data.columnOrder[action.column.boardId], action.column.id] }, cardOrder: { ...data.cardOrder, [action.column.id]: [] } });
    case "RENAME_COLUMN":
      return saveStep(state, { ...data, columns: { ...data.columns, [action.id]: { ...data.columns[action.id], title: action.title } } });
    case "DELETE_COLUMN": {
      const column = data.columns[action.id];
      const columns = { ...data.columns };
      const cards = { ...data.cards };
      (data.cardOrder[action.id] || []).forEach((id) => delete cards[id]);
      delete columns[action.id];
      const cardOrder = { ...data.cardOrder };
      delete cardOrder[action.id];
      return saveStep(state, { ...data, columns, cards, cardOrder, columnOrder: { ...data.columnOrder, [column.boardId]: data.columnOrder[column.boardId].filter((id) => id !== action.id) } });
    }
    case "ADD_CARD":
      return saveStep(state, { ...data, cards: { ...data.cards, [action.card.id]: action.card }, cardOrder: { ...data.cardOrder, [action.card.columnId]: [...data.cardOrder[action.card.columnId], action.card.id] } });
    case "UPDATE_CARD":
      return saveStep(state, { ...data, cards: { ...data.cards, [action.id]: { ...data.cards[action.id], ...action.changes } } });
    case "DELETE_CARD": {
      const card = data.cards[action.id];
      const cards = { ...data.cards };
      delete cards[action.id];
      return saveStep(state, { ...data, cards, cardOrder: { ...data.cardOrder, [card.columnId]: data.cardOrder[card.columnId].filter((id) => id !== action.id) } });
    }
    case "MOVE_CARD": {
      const card = data.cards[action.id];
      const sourceId = card.columnId;
      const source = data.cardOrder[sourceId].filter((id) => id !== card.id);
      const target = sourceId === action.columnId ? source : [...data.cardOrder[action.columnId]];
      target.splice(Math.max(0, Math.min(action.index, target.length)), 0, card.id);
      return saveStep(state, { ...data, cards: { ...data.cards, [card.id]: { ...card, columnId: action.columnId } }, cardOrder: { ...data.cardOrder, [sourceId]: sourceId === action.columnId ? target : source, [action.columnId]: target } });
    }
    case "ADD_MANY": {
      const cards = { ...data.cards };
      action.cards.forEach((card) => { cards[card.id] = card; });
      return saveStep(state, { ...data, cards, cardOrder: { ...data.cardOrder, [action.columnId]: [...data.cardOrder[action.columnId], ...action.cards.map((card) => card.id)] } });
    }
    default:
      return state;
  }
}
