import { useEffect, useState } from "react";

export function useLocalStorage(key, startValue, delay = 350) {
  const [value, setValue] = useState(() => {
    try {
      const saved = localStorage.getItem(key);
      return saved ? JSON.parse(saved) : startValue;
    } catch {
      return startValue;
    }
  });

  useEffect(() => {
    const timer = setTimeout(() => localStorage.setItem(key, JSON.stringify(value)), delay);
    return () => clearTimeout(timer);
  }, [key, value, delay]);

  return [value, setValue];
}
