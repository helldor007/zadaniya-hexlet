import { useState } from "react";
import { useStore } from "./Store";
import { makeId } from "./data";

export default function BoardsPage({ navigate }) {
  const { state, change } = useStore();
  const [name, setName] = useState("");
  const [editing, setEditing] = useState(null);

  function addBoard(event) {
    event.preventDefault();
    if (!name.trim()) return;
    const id = makeId();
    change({ type: "ADD_BOARD", board: { id, title: name.trim() } });
    setName("");
  }

  function renameBoard(board) {
    const title = prompt("Новое название доски", board.title);
    if (title?.trim()) change({ type: "RENAME_BOARD", id: board.id, title: title.trim() });
    setEditing(null);
  }

  return (
    <main className="boards-page">
      <div className="page-title-row"><div><p className="eyebrow">Ваше пространство</p><h1>Мои доски</h1></div></div>
      <form className="create-board" onSubmit={addBoard}>
        <input value={name} onChange={(event) => setName(event.target.value)} placeholder="Название новой доски" aria-label="Название новой доски" />
        <button className="button primary" type="submit">Создать доску</button>
      </form>
      <div className="boards-grid">
        {state.boardOrder.map((id) => {
          const board = state.boards[id];
          return <article className="board-tile" key={id}>
            <button className="board-open" onClick={() => navigate(`/boards/${id}`)}>
              <span className="tile-icon">▦</span><span>{board.title}</span><small>{(state.columnOrder[id] || []).length} колонки</small>
            </button>
            <div className="tile-actions">
              <button onClick={() => renameBoard(board)}>Переименовать</button>
              <button className="danger-text" onClick={() => change({ type: "DELETE_BOARD", id })}>Удалить</button>
            </div>
          </article>;
        })}
      </div>
      {state.boardOrder.length === 0 && <p className="empty-state">Досок пока нет. Создайте первую выше.</p>}
    </main>
  );
}
