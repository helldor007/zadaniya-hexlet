import { describe, expect, it } from "vitest";
import { initialState, reducer } from "./reducer";

describe("reducer: все действия", () => {
  it("создаёт, переименовывает и удаляет доску вместе с содержимым", () => {
    let state = reducer(initialState, { type: "ADD_BOARD", board: { id: "b2", title: "Новая" } });
    state = reducer(state, { type: "RENAME_BOARD", id: "b2", title: "Работа" });
    expect(state.boards.b2.title).toBe("Работа");
    state = reducer(state, { type: "ADD_COLUMN", column: { id: "x", boardId: "b2", title: "Список" } });
    state = reducer(state, { type: "ADD_CARD", card: { id: "y", columnId: "x", title: "Задача", description: "", tags: [] } });
    state = reducer(state, { type: "DELETE_BOARD", id: "b2" });
    expect(state.boards.b2).toBeUndefined();
    expect(state.cards.y).toBeUndefined();
  });

  it("создаёт, переименовывает и удаляет колонку с её карточками", () => {
    let state = reducer(initialState, { type: "ADD_COLUMN", column: { id: "x", boardId: "demo", title: "Список" } });
    state = reducer(state, { type: "RENAME_COLUMN", id: "x", title: "Новый список" });
    expect(state.columns.x.title).toBe("Новый список");
    state = reducer(state, { type: "ADD_CARD", card: { id: "y", columnId: "x", title: "Задача", description: "", tags: [] } });
    state = reducer(state, { type: "DELETE_COLUMN", id: "x" });
    expect(state.columns.x).toBeUndefined();
    expect(state.cards.y).toBeUndefined();
  });

  it("добавляет, редактирует, перемещает, удаляет карточку и поддерживает массовое добавление", () => {
    const card = { id: "new", columnId: "todo", title: "Новая", description: "", tags: [] };
    let state = reducer(initialState, { type: "ADD_CARD", card });
    state = reducer(state, { type: "UPDATE_CARD", id: "new", changes: { title: "Изменённая" } });
    expect(state.cards.new.title).toBe("Изменённая");
    state = reducer(state, { type: "MOVE_CARD", id: "new", columnId: "done", index: 0 });
    expect(state.cards.new.columnId).toBe("done");
    const many = [{ id: "m1", columnId: "done", title: "А", description: "", tags: [] }, { id: "m2", columnId: "done", title: "Б", description: "", tags: [] }];
    state = reducer(state, { type: "ADD_MANY", columnId: "done", cards: many });
    expect(state.cardOrder.done).toContain("m2");
    state = reducer(state, { type: "DELETE_CARD", id: "new" });
    expect(state.cards.new).toBeUndefined();
  });

  it("делает Undo и Redo, синхронизирует вкладку и ограничивает историю 50 шагами", () => {
    let state = reducer(initialState, { type: "RENAME_BOARD", id: "demo", title: "Второе" });
    state = reducer(state, { type: "UNDO" });
    expect(state.boards.demo.title).toBe("Моя первая доска");
    state = reducer(state, { type: "REDO" });
    expect(state.boards.demo.title).toBe("Второе");
    state = reducer(state, { type: "SYNC", data: { ...initialState, boards: { demo: { id: "demo", title: "Из другой вкладки" } } } });
    expect(state.boards.demo.title).toBe("Из другой вкладки");
    for (let index = 0; index < 55; index++) state = reducer(state, { type: "RENAME_BOARD", id: "demo", title: `Шаг ${index}` });
    expect(state.past).toHaveLength(50);
  });

  it("оставляет состояние прежним для пустой истории и восстанавливает снимок", () => {
    expect(reducer(initialState, { type: "UNDO" })).toBe(initialState);
    expect(reducer(initialState, { type: "REDO" })).toBe(initialState);
    const changed = reducer(initialState, { type: "RENAME_BOARD", id: "demo", title: "Изменено" });
    expect(reducer(changed, { type: "RESTORE", state: initialState })).toBe(initialState);
  });
});
