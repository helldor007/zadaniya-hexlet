import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useStore } from "./Store";
import { makeId } from "./data";

const ITEM_HEIGHT = 116;

function CardModal({ card, onSave, onClose }) {
  const [title, setTitle] = useState(card?.title || "");
  const [description, setDescription] = useState(card?.description || "");
  const [tags, setTags] = useState((card?.tags || []).join(", "));
  const titleRef = useRef(null);

  useEffect(() => {
    titleRef.current?.focus();
    function onKeyDown(event) {
      if (event.key === "Escape") onClose();
      if (event.key === "Tab") {
        const items = [...document.querySelectorAll(".dialog button, .dialog input, .dialog textarea")].filter((el) => !el.disabled);
        const first = items[0];
        const last = items[items.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
    }
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [onClose]);

  function submit(event) {
    event.preventDefault();
    if (!title.trim()) return;
    onSave({ title: title.trim(), description: description.trim(), tags: tags.split(",").map((tag) => tag.trim()).filter(Boolean) });
  }

  return createPortal(
    <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <form className="dialog" role="dialog" aria-modal="true" aria-labelledby="dialog-title" onSubmit={submit}>
        <h2 id="dialog-title">{card ? "Редактировать карточку" : "Новая карточка"}</h2>
        <label>Название<input ref={titleRef} value={title} onChange={(event) => setTitle(event.target.value)} /></label>
        <label>Описание<textarea rows="4" value={description} onChange={(event) => setDescription(event.target.value)} /></label>
        <label>Теги<input value={tags} onChange={(event) => setTags(event.target.value)} placeholder="через запятую" /></label>
        <div className="dialog-actions"><button type="button" className="button quiet" onClick={onClose}>Отмена</button><button className="button primary" type="submit">Сохранить</button></div>
      </form>
    </div>, document.body
  );
}

function VirtualCards({ ids, state, columnId, onEdit, onMove, onDelete, draggingId, setDraggingId }) {
  const scroller = useRef(null);
  const [scrollTop, setScrollTop] = useState(0);
  const [height, setHeight] = useState(430);
  useEffect(() => {
    if (!scroller.current) return;
    const observer = new ResizeObserver(([entry]) => setHeight(entry.contentRect.height));
    observer.observe(scroller.current);
    return () => observer.disconnect();
  }, []);
  const start = Math.max(0, Math.floor(scrollTop / ITEM_HEIGHT) - 2);
  const end = Math.min(ids.length, Math.ceil((scrollTop + height) / ITEM_HEIGHT) + 2);
  const visibleIds = ids.slice(start, end);

  return <div
    className="card-scroller"
    ref={scroller}
    onScroll={(event) => setScrollTop(event.currentTarget.scrollTop)}
    onDragOver={(event) => event.preventDefault()}
    onDrop={(event) => {
      event.preventDefault();
      const id = event.dataTransfer.getData("text/plain") || draggingId;
      if (id) onMove(id, columnId, ids.length);
      setDraggingId(null);
    }}
  >
    <div style={{ height: start * ITEM_HEIGHT, pointerEvents: "none" }} />
    {visibleIds.map((id, offset) => {
      const card = state.cards[id];
      if (!card) return null;
      return <article
        className="task-card"
        key={id}
        tabIndex="0"
        draggable
        onDragStart={(event) => { setDraggingId(id); event.dataTransfer.setData("text/plain", id); }}
        onDragEnd={() => setDraggingId(null)}
        onDragOver={(event) => event.preventDefault()}
        onDrop={(event) => {
          event.preventDefault(); event.stopPropagation();
          const movingId = event.dataTransfer.getData("text/plain") || draggingId;
          if (movingId) onMove(movingId, columnId, ids.indexOf(id));
          setDraggingId(null);
        }}
        onKeyDown={(event) => {
          if (event.key === "Enter") onEdit(card, event.currentTarget.querySelector(".card-edit"));
        }}
      >
        <button className="card-edit" aria-label={`Изменить ${card.title}`} onClick={(event) => onEdit(card, event.currentTarget)}>
          <span className="task-title">{card.title}</span>
          {card.description && <span className="task-description">{card.description}</span>}
          {!!card.tags.length && <span className="tag-row">{card.tags.map((tag) => <span className="tag" key={tag}>{tag}</span>)}</span>}
        </button>
        <button className="delete-card" aria-label={`Удалить ${card.title}`} onClick={() => onDelete(id)}>×</button>
      </article>;
    })}
    <div style={{ height: Math.max(0, (ids.length - end) * ITEM_HEIGHT), pointerEvents: "none" }} />
    {ids.length === 0 && <p className="empty-column">Перетащите карточку сюда<br />или создайте новую</p>}
  </div>;
}

export default function BoardPage({ boardId, navigate }) {
  const { state, change } = useStore();
  const board = state.boards[boardId];
  const [query, setQuery] = useState(new URLSearchParams(location.search).get("q") || "");
  const [tags, setTags] = useState(new URLSearchParams(location.search).get("tags")?.split(",").filter(Boolean) || []);
  const [modal, setModal] = useState(null);
  const [draggingId, setDraggingId] = useState(null);
  const [columnName, setColumnName] = useState("");
  const [theme, setTheme] = useState(localStorage.getItem("kanban-theme") || (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"));
  const searchRef = useRef(null);
  const opener = useRef(null);
  const order = state.columnOrder[boardId] || [];
  const availableTags = [...new Set(order.flatMap((columnId) => state.cardOrder[columnId] || []).flatMap((id) => state.cards[id]?.tags || []))];

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    localStorage.setItem("kanban-theme", theme);
  }, [theme]);

  useEffect(() => {
    const params = new URLSearchParams();
    if (query) params.set("q", query);
    if (tags.length) params.set("tags", tags.join(","));
    history.replaceState(null, "", `${location.pathname}${params.toString() ? `?${params}` : ""}`);
  }, [query, tags]);

  useEffect(() => {
    function keyHandler(event) {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "z") {
        event.preventDefault(); window.dispatchEvent(new CustomEvent(event.shiftKey ? "kanban-redo" : "kanban-undo"));
      } else if (event.key === "/" && !["INPUT", "TEXTAREA"].includes(document.activeElement.tagName)) {
        event.preventDefault(); searchRef.current?.focus();
      } else if (event.key.toLowerCase() === "n" && !["INPUT", "TEXTAREA"].includes(document.activeElement.tagName)) {
        event.preventDefault(); openNew(order[0]);
      } else if (event.key.startsWith("Arrow") && document.activeElement.classList.contains("task-card")) {
        const cards = [...document.querySelectorAll(".task-card")];
        const index = cards.indexOf(document.activeElement);
        const step = event.key === "ArrowDown" || event.key === "ArrowRight" ? 1 : -1;
        cards[Math.max(0, Math.min(cards.length - 1, index + step))]?.focus();
      }
    }
    window.addEventListener("keydown", keyHandler);
    return () => window.removeEventListener("keydown", keyHandler);
  }, [order]);

  if (!board) return <main className="not-found"><h1>Доска не найдена</h1><button className="button primary" onClick={() => navigate("/boards")}>К списку досок</button></main>;

  function filteredIds(columnId) {
    return (state.cardOrder[columnId] || []).filter((id) => {
      const card = state.cards[id];
      const textMatches = `${card.title} ${card.description}`.toLowerCase().includes(query.toLowerCase());
      return textMatches && tags.every((tag) => card.tags.includes(tag));
    });
  }

  function openNew(columnId) {
    if (!columnId) return;
    opener.current = document.activeElement;
    setModal({ columnId, card: null });
  }

  function closeModal() {
    setModal(null);
    setTimeout(() => opener.current?.focus?.(), 0);
  }

  function saveCard(values) {
    if (modal.card) change({ type: "UPDATE_CARD", id: modal.card.id, changes: values });
    else change({ type: "ADD_CARD", card: { id: makeId(), columnId: modal.columnId, ...values } });
    closeModal();
  }

  function moveCard(id, columnId, index) {
    change({ type: "MOVE_CARD", id, columnId, index });
  }

  function createColumn(event) {
    event.preventDefault();
    if (!columnName.trim()) return;
    const id = makeId();
    change({ type: "ADD_COLUMN", column: { id, boardId, title: columnName.trim() } });
    setColumnName("");
  }

  function editColumn(column) {
    const title = prompt("Название колонки", column.title);
    if (title?.trim()) change({ type: "RENAME_COLUMN", id: column.id, title: title.trim() });
  }

  return <main className="board-page">
    <div className="board-toolbar">
      <div className="crumbs"><button onClick={() => navigate("/boards")}>← Доски</button><span>/</span><h1>{board.title}</h1></div>
      <div className="toolbar-actions">
        <input ref={searchRef} className="search-input" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Поиск…  /" aria-label="Поиск по карточкам" />
        <button className="button quiet generate-button" onClick={() => {
          if (!order[0]) return;
          const manyCards = Array.from({ length: 10000 }, (_, index) => ({ id: makeId(), columnId: order[0], title: `Тестовая карточка ${index + 1}`, description: "Карточка для проверки виртуального списка.", tags: ["тест"] }));
          change({ type: "ADD_MANY", columnId: order[0], cards: manyCards });
        }}>＋ 10 000</button>
        <button className="button quiet" title="Отменить (Ctrl+Z)" onClick={() => window.dispatchEvent(new Event("kanban-undo"))}>↶</button>
        <button className="button quiet" title="Повторить (Ctrl+Shift+Z)" onClick={() => window.dispatchEvent(new Event("kanban-redo"))}>↷</button>
        <button className="button quiet theme-button" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>{theme === "dark" ? "☀" : "☾"}</button>
      </div>
    </div>
    {availableTags.length > 0 && <div className="filter-row"><span>Теги:</span>{availableTags.map((tag) => <button key={tag} className={`filter-chip ${tags.includes(tag) ? "selected" : ""}`} onClick={() => setTags(tags.includes(tag) ? tags.filter((item) => item !== tag) : [...tags, tag])}>{tag}</button>)}</div>}
    <div className="columns-row">
      {order.map((columnId) => {
        const column = state.columns[columnId];
        return <section className="column" key={columnId} onDragOver={(event) => event.preventDefault()} onDrop={(event) => {
          if (event.target.closest(".task-card")) return;
          const id = event.dataTransfer.getData("text/plain") || draggingId;
          if (id) moveCard(id, columnId, state.cardOrder[columnId].length);
          setDraggingId(null);
        }}>
          <div className="column-head"><h2>{column.title}<span>{filteredIds(columnId).length}</span></h2><div className="column-actions"><button title="Переименовать колонку" onClick={() => editColumn(column)}>···</button><button title="Удалить колонку" onClick={() => change({ type: "DELETE_COLUMN", id: columnId })}>×</button></div></div>
          <VirtualCards ids={filteredIds(columnId)} state={state} columnId={columnId} onEdit={(card, button) => { opener.current = button || document.activeElement; setModal({ columnId, card }); }} onMove={moveCard} onDelete={(id) => change({ type: "DELETE_CARD", id })} draggingId={draggingId} setDraggingId={setDraggingId} />
          <button className="add-card" onClick={() => openNew(columnId)}>＋ Добавить карточку</button>
        </section>;
      })}
      <form className="add-column" onSubmit={createColumn}><input value={columnName} onChange={(event) => setColumnName(event.target.value)} placeholder="Новая колонка" aria-label="Название новой колонки" /><button className="button primary" type="submit">＋</button></form>
    </div>
    {modal && <CardModal card={modal.card} onSave={saveCard} onClose={closeModal} />}
  </main>;
}
