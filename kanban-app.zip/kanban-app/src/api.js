export function fakeSave() {
  const wait = 300 + Math.random() * 500;
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (Math.random() < 0.2) reject(new Error("Сервер не ответил. Изменение отменено."));
      else resolve();
    }, wait);
  });
}
